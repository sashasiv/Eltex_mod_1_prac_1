#!/bin/bash
# cuckoo.sh — кукушка кукушка сколько времени ты процессу накукуешь
set -u

# Создает именованный канал с именем, указанном c абсолютным путем в параметре запуска скрипта --pishitesuda=

PIPE=""
for arg in "$@"; do
    case "$arg" in
        --pishitesuda=*)
            PIPE="${arg#--pishitesuda=}"
            ;;
    esac
done

if [ -z "$PIPE" ]; then
    echo "Используйте: $0 --pishitesuda=/путь/к/файлу" >&2
    exit 1
fi

case "$PIPE" in
    /*) ;;
    *)  echo "Ошибка: доступен только абсолютный путь" >&2; exit 1 ;;
esac

LOG="cuckoo.log"
PIDFILE="/run/cuckoo.pid"

# Запись лога 
log() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"
}

# Создание канала
[ -p "$PIPE" ] && rm -f "$PIPE"
mkfifo "$PIPE"
echo $$ > "$PIDFILE"
log "Startup!"

# Завершение 
cleanup() {
    log "Shutdown!"
    rm -f "$PIPE" "$PIDFILE"
    exit 0
}
trap cleanup SIGTERM SIGINT

# Основной цикл чтения

exec 3<> "$PIPE"
while true; do
    if IFS= read -r line <&3; then
        # ожидаемый формат: NAME[PID]: how much time do I have?
        if [[ "$line" =~ ^([^[]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            RPID="${BASH_REMATCH[2]}"
            N=$(( RANDOM % 9 + 2 ))     # 2..10
            echo "$N" >&3                # ответ обратно в канал
	    sleep 0.5
            log "$NAME[$RPID] $N"
        fi
    else
        sleep 0.2                    # защита от busy-loop
    fi
done
