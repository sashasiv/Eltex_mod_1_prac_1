#!/bin/bash
# observer.sh — Надсмотрщик над скриптами

set -u

CONF="$(dirname "$(readlink -f "$0")")/observer.conf"
LOG="observer.log"

log() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"
}

[ -f "$CONF" ] || { log "CONF not found: $CONF"; exit 1; }

# Читаем конфиг
while IFS= read -r line; do
    # пропускаем пустые строки и комментарии
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    # абсолютный путь к исполняемому файлу (после симлинков)
    target="$(readlink -f "$line")"
    [ -n "$target" ] && [ -x "$target" ] || { log "SKIP (not executable): $line"; continue; }

    # Ищем процесс по /proc 
    found=0
    for pid in /proc/[0-9]*; do
        [ -r "$pid/cmdline" ] || continue
        # cmdline: argv, разделённые \0
        cmd="$(tr '\0' ' ' < "$pid/cmdline" 2>/dev/null)"
        # сравниваем имя как в $0 при запуске (может быть путь или имя)
        if [[ "$cmd" == *"$line"* || "$cmd" == *"$(basename "$line")"* ]]; then
            # исключаем самих себя
            [ "${pid##*/}" = "$$" ] && continue
            found=1
            break
        fi
    done

    # Перезапуск 
    if [ "$found" -eq 0 ]; then
        nohup "$line" >/dev/null 2>&1 &
        log "RESTART: $line (launched pid $!)"
	sleep 1
    fi
done < "$CONF"
