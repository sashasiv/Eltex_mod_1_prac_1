#!/bin/bash
# template_task.sh — бригадир спрашивает у кукушки кто сколько работать будет

set -u

PIPE_DEFAULT="/run/cuckoo.pipe"
PIPE="${CUCKOO_PIPE:-$PIPE_DEFAULT}"

SELF_NAME="$(basename "$0")"
SELF_PID=$$
LOG="report_${SELF_NAME}.log"

log() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"
}

# «Я бригадир, сам не работаю»
if [ "$SELF_NAME" = "template_task.sh" ]; then
    echo "Я бригадир, сам не работаю"
    exit 0
fi

# Запись старта
log "[$SELF_PID] Скрипт запущен"

# Запрос к кукушке 
NAME="$SELF_NAME"
RESP=""
RC=0

if [ -p "$PIPE" ]; then 
    exec 4> "$PIPE" 
    printf '%s[%d]: how much time do I have?\n' "$NAME" "$SELF_PID" >&4 
    exec 4>&-
    sleep 0.5
    exec 5< "$PIPE"
    IFS= read -r -t 5 RESP <&5 
    RC=$?
    exec 5<&-
fi

# Проверка ответа
if ! [[ "$RESP" =~ ^[0-9]+$ ]]; then 
    log "[$SELF_PID] Ошибка: кукушка молчит, похоже у нас выходной"
    exit 1
fi 

START_TS=$(date +%s) 
sleep "$RESP" 
END_TS=$(date +%s) WORKED=$(( END_TS - START_TS ))

log "[$SELF_PID] Скрипт завершился, работал $WORKED секунд"
